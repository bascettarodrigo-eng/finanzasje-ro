# Je&Ro Finanzas — guía de publicación e instalación

App de gastos para Jesi, Rodrigo y Emma, inspirada en Monefy. Es una PWA: se publica en Netlify y se instala en el iPhone desde Safari, con ícono propio y pantalla completa, sin pasar por la App Store.

## Qué incluye

| Sección | Qué hace |
|---|---|
| **Rubros** | Generales (supermercado, casa, servicios, etc.), un grupo **Emma** (Guardería, Niñera, Cuidado personal) que se marca como compartido, y **Varios / Otros** con título breve obligatorio y descripción. |
| **Inicio** | Gráfico de anillo por rubro, balance del período (día, semana, mes, año) y lista de movimientos. Botones rápidos − Gasto / + Ingreso. |
| **Vistas** | *En conjunto*, *Rodrigo* o *Jesi*. En la vista personal se puede sumar la mitad de los gastos compartidos. |
| **Análisis** | Ingresos, gastos, ahorro y tasa de ahorro; fijos vs variables vs extraordinarios; últimos 6 meses; variación por rubro vs mes anterior; medios de pago; quién gastó qué y cuánto le debe uno al otro de lo compartido; tarjeta **Gastos de Emma** con total, % del gasto y promedio mensual. |
| **Tarjetas** | Cada compra con tarjeta guarda cuotas, interés, descuento/promo, reintegro y precio de contado. Calcula el valor presente de las cuotas y dice si convino (Conveniente / Neutral / No conveniente), el ahorro total y el cronograma de cuotas de los próximos 6 meses. |
| **Inversiones** | Dólar oficial, MEP, blue, CCL y tarjeta; tasas de plazo fijo por banco; inflación; rendimiento de FCI money market (incluye Fima). Cartera propia, capacidad de ahorro, fondo de emergencia y **asesor con IA**. |
| **Ajustes** | Quién usa el teléfono, sincronización entre los dos iPhone, tarjetas, tasa para evaluar cuotas, exportar/importar copia y CSV. |

## Estructura

```
index.html                  la app completa
manifest.webmanifest, sw.js instalación en iPhone y uso sin conexión
icons/                      ícono de la app y logo Je&Ro Finanzas
netlify/functions/
  sync.mjs                  sincroniza los datos entre teléfonos (Netlify Blobs)
  mercado.mjs               junta cotizaciones y tasas (DolarApi + ArgentinaDatos)
  asesor.mjs                asesor de inversiones con Claude (IA)
netlify.toml, package.json  configuración de Netlify
```

## 1. Publicar en Netlify

Las funciones (sincronización, mercado e IA) necesitan que Netlify instale dependencias, así que **no sirve arrastrar la carpeta** a Netlify Drop: así la app abre pero sin sincronizar ni IA. Usá una de estas dos opciones:

**Opción A — GitHub (recomendada, se actualiza sola)**
1. Creá un repositorio en GitHub (puede ser privado) y subí todo el contenido de esta carpeta.
2. En [app.netlify.com](https://app.netlify.com): *Add new site → Import an existing project → GitHub* y elegí el repositorio.
3. Dejá los valores por defecto (no hace falta comando de build; el directorio de publicación es `.`). *Deploy*.

**Opción B — Netlify CLI desde la PC**
```bash
cd caja-familiar
npm install
npx netlify-cli login
npx netlify-cli deploy --prod
```

## 2. Variables de entorno (Site configuration → Environment variables)

| Variable | Para qué | Obligatoria |
|---|---|---|
| `ANTHROPIC_API_KEY` | Activa el asesor con IA. Se crea en [console.anthropic.com](https://console.anthropic.com) → API Keys. Se paga por uso (cada análisis cuesta centavos de dólar). | Para la IA |
| `APP_PIN` | Si la ponés, la sincronización y el asesor solo funcionan con ese PIN. Evita que alguien que encuentre la URL use tu clave de IA. | Recomendada |
| `ANTHROPIC_MODEL` | Cambia el modelo (por defecto `claude-sonnet-5-5`). | No |

Después de cargar variables, hacé *Deploys → Trigger deploy* para que tomen efecto.

Sin `ANTHROPIC_API_KEY` la app igual muestra un **análisis automático** basado en reglas (tasa de ahorro, fondo de emergencia, tasa real del plazo fijo, distribución según perfil).

## 3. Instalar en el iPhone (los dos)

1. Abrí la URL de Netlify en **Safari** (tiene que ser Safari).
2. Botón **Compartir** → **Agregar a pantalla de inicio** → *Agregar*.
3. Abrí la app desde el ícono. En **Ajustes → ¿Quién usa este teléfono?** elegí Rodrigo o Jesi.
4. En **Ajustes → Sincronizar**, poné el **mismo código familiar y el mismo PIN** en ambos teléfonos (si configuraste `APP_PIN`, el PIN debe ser ese).
5. La primera vez verás **datos de ejemplo**: tocá *Empezar de cero* antes de cargar los reales. Los ejemplos nunca se sincronizan.

## Cómo se calcula si una compra en cuotas convino

- **Total en cuotas** = precio de lista − descuento (o el total financiado, si es con interés).
- Cada cuota se trae a **valor de hoy** con una tasa mensual: por defecto la TNA de plazo fijo de los bancos grandes ÷ 12 (lo que hubiera rendido esa plata). Se puede cambiar a inflación o a una tasa manual.
- **Ahorro** = precio de contado − (valor presente de las cuotas − reintegro).
- Más de +2 % del precio: *Conveniente*. Menos de −2 %: *No conveniente*. En el medio: *Neutral*.
- Para compras con interés se muestra el CFT anual aproximado.

## Datos y privacidad

- Todo se guarda en el teléfono. Con la sincronización activa, también en Netlify Blobs de tu cuenta, identificado por un hash del código + PIN.
- Cotizaciones: DolarApi. Tasas, inflación y FCI: ArgentinaDatos (fuentes BCRA, INDEC y CAFCI).
- Hacé una copia con **Ajustes → Exportar copia** de vez en cuando.
- Las sugerencias del asesor son orientativas y no reemplazan a un asesor financiero matriculado.
