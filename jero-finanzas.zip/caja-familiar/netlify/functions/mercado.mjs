// Junta cotizaciones y tasas de fuentes públicas en una sola llamada (con caché de 15 min).
// DolarApi: dólar oficial, MEP, blue, CCL, tarjeta.
// ArgentinaDatos: tasas de plazo fijo por banco (BCRA), inflación (INDEC), FCI money market (CAFCI).
const FUENTES = {
  dolares: 'https://dolarapi.com/v1/dolares',
  plazoFijo: 'https://api.argentinadatos.com/v1/finanzas/tasas/plazoFijo',
  inflacion: 'https://api.argentinadatos.com/v1/finanzas/indices/inflacion',
  fciU: 'https://api.argentinadatos.com/v1/finanzas/fci/mercadoDinero/ultimo',
  fciP: 'https://api.argentinadatos.com/v1/finanzas/fci/mercadoDinero/penultimo'
};

const recortarFci = (l) => Array.isArray(l) ? l.map(f => ({ fondo: f.fondo, fecha: f.fecha, vcp: f.vcp, patrimonio: f.patrimonio })) : null;

export default async () => {
  const pares = await Promise.all(Object.entries(FUENTES).map(async ([k, url]) => {
    try {
      const r = await fetch(url, { signal: AbortSignal.timeout(8000) });
      return [k, r.ok ? await r.json() : null];
    } catch { return [k, null]; }
  }));
  const d = Object.fromEntries(pares);
  if (Array.isArray(d.inflacion)) d.inflacion = d.inflacion.slice(-13);
  d.fciU = recortarFci(d.fciU);
  d.fciP = recortarFci(d.fciP);
  d.actualizado = new Date().toISOString();
  return new Response(JSON.stringify(d), {
    headers: { 'content-type': 'application/json', 'cache-control': 'public, max-age=900' }
  });
};

export const config = { path: '/api/mercado' };
