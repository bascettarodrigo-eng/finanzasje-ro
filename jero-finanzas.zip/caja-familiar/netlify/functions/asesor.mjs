// Asesor financiero con IA (Claude). Recibe un resumen de las finanzas familiares
// y devuelve el análisis en streaming (Server-Sent Events) para que aparezca de a poco.
// Requiere la variable de entorno ANTHROPIC_API_KEY en Netlify.

const SYSTEM = `Sos un asesor financiero para una familia de Rosario, Argentina: Rodrigo, Jesi y su hija bebé Emma.
Los gastos de Emma (guardería, niñera, cuidado personal) vienen en el JSON; tenelos en cuenta como gastos que van a seguir y crecer, y si tiene sentido mencioná ahorrar a largo plazo para ella.
Recibís un resumen en JSON con sus ingresos, gastos, cuotas de tarjeta, cartera de inversiones y datos de mercado del día (dólar, tasas de plazo fijo, inflación, FCI money market).

Tu tarea: analizar su situación y sugerir cómo manejar el ahorro con instrumentos disponibles en Argentina: FCI money market (por ejemplo Fima Premium), FCI T+1, plazo fijo tradicional y UVA, dólar MEP, Lecaps/bonos CER, CEDEARs.

Reglas:
- Escribí en español rioplatense, claro y concreto, como hablarías con una pareja que no es experta.
- Usá SOLO los números del JSON. Si falta un dato, decilo y no lo inventes. No inventes tasas ni cotizaciones.
- Calculá la tasa real (tasa del instrumento vs inflación mensual) cuando tengas los datos.
- Respetá el perfil de riesgo y el horizonte que indican. Con horizonte corto priorizá liquidez.
- Primero el fondo de emergencia (3 a 6 meses de gastos en algo líquido), después el resto.
- Si la tasa de ahorro es baja o hay muchas cuotas comprometidas, decilo antes de sugerir inversiones.
- Proponé una distribución del ahorro mensual en porcentajes y en pesos.
- Si hay una pregunta puntual, respondela primero.
- Explicá ventajas y riesgos de cada opción en una línea. No prometas rendimientos.

Formato (markdown simple, máximo ~450 palabras):
## Diagnóstico
## Fondo de emergencia
## Qué haría con el ahorro de este mes
## Tarjeta y cuotas
## Próximos pasos
Cerrá con una línea en cursiva aclarando que es orientativo y no reemplaza a un asesor matriculado (ALyC/CNV).`;

const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json' } });

export default async (req) => {
  if (req.method !== 'POST') return json({ error: 'Método no permitido' }, 405);

  const pinRequerido = process.env.APP_PIN;
  if (pinRequerido && req.headers.get('x-pin') !== pinRequerido) {
    return json({ error: 'PIN incorrecto. Revisalo en Ajustes > Sincronizar.' }, 401);
  }

  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return json({ error: 'falta configurar ANTHROPIC_API_KEY en Netlify' }, 503);

  let datos;
  try { datos = await req.json(); } catch { return json({ error: 'Datos inválidos' }, 400); }
  const pregunta = String(datos.pregunta || '').slice(0, 600);

  const upstream = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
      max_tokens: 2000,
      stream: true,
      system: SYSTEM,
      messages: [{
        role: 'user',
        content: `Datos financieros de la familia (JSON):\n${JSON.stringify(datos, null, 1)}\n\n${pregunta ? 'Pregunta puntual: ' + pregunta : 'Hacé el análisis completo.'}`
      }]
    })
  });

  if (!upstream.ok) {
    const t = await upstream.text();
    return json({ error: `la API de Claude respondió ${upstream.status}: ${t.slice(0, 200)}` }, 502);
  }

  return new Response(upstream.body, {
    headers: { 'content-type': 'text/event-stream; charset=utf-8', 'cache-control': 'no-store' }
  });
};

export const config = { path: '/api/asesor' };
