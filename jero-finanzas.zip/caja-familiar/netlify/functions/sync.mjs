// Sincroniza los datos entre los teléfonos de la familia usando Netlify Blobs.
// Cada familia se identifica con un código + PIN (se guarda un hash, nunca el PIN).
// Fusiona registro por registro: gana la versión con updatedAt más reciente.
import { getStore } from '@netlify/blobs';
import { createHash } from 'node:crypto';

const json = (obj, status = 200) => new Response(JSON.stringify(obj), {
  status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' }
});

const merge = (a = [], b = []) => {
  const m = new Map();
  for (const x of [...a, ...b]) {
    if (!x || !x.id) continue;
    const p = m.get(x.id);
    if (!p || (x.updatedAt || 0) > (p.updatedAt || 0)) m.set(x.id, x);
  }
  return [...m.values()];
};

export default async (req) => {
  const familia = (req.headers.get('x-familia') || '').trim().toLowerCase();
  const pin = req.headers.get('x-pin') || '';
  if (familia.length < 4 || pin.length < 4) {
    return json({ error: 'Configurá un código familiar y un PIN de al menos 4 caracteres.' }, 400);
  }
  if (process.env.APP_PIN && pin !== process.env.APP_PIN) {
    return json({ error: 'PIN incorrecto.' }, 401);
  }

  const key = 'familia-' + createHash('sha256').update(familia + ':' + pin).digest('hex').slice(0, 40);
  const store = getStore({ name: 'caja-familiar', consistency: 'strong' });
  const actual = (await store.get(key, { type: 'json' })) || { tx: [], inv: [], shared: null };

  if (req.method === 'GET') return json(actual);
  if (req.method !== 'POST') return json({ error: 'Método no permitido' }, 405);

  let entrante;
  try { entrante = await req.json(); } catch { return json({ error: 'Datos inválidos' }, 400); }

  const out = {
    tx: merge(actual.tx, entrante.tx),
    inv: merge(actual.inv, entrante.inv),
    shared: ((entrante.shared && entrante.shared.updatedAt) || 0) > ((actual.shared && actual.shared.updatedAt) || 0) ? entrante.shared : actual.shared,
    actualizado: Date.now()
  };
  await store.setJSON(key, out);
  return json(out);
};

export const config = { path: '/api/sync' };
